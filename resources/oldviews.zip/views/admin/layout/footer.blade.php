<footer class="px-4 py-3 footer d-flex flex-column flex-md-row align-items-center justify-content-between border-top small">
    <p class="mb-1 text-muted mb-md-0">Copyright © 2024 <a href="https://www.salprojects.org" target="_blank">SAL Projects</a>.</p>
    <p class="text-muted">Handcrafted With <i class="mb-1 text-primary ms-1 icon-sm" data-feather="heart"></i></p>
</footer>
