@extends('layouts.app')

@section('content')
<div class="container mt-5">
    <h2>Skill Training Development Project - Quarterly Progress Report</h2>
    <form action="{{ route('reports.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <!-- Basic Project Information -->
        <div class="mb-3 form-group">
            <label for="period">Period</label>
            <input type="text" class="form-control" id="period" name="period" placeholder="From... To..." required>
        </div>
        <div class="mb-3 form-group">
            <label for="title">Title of the Project</label>
            <input type="text" class="form-control" id="title" name="title" required>
        </div>
        <div class="mb-3 form-group">
            <label for="place">Place</label>
            <input type="text" class="form-control" id="place" name="place" required>
        </div>
        <div class="mb-3 form-group">
            <label for="society">Name of the Society / Trust</label>
            <input type="text" class="form-control" id="society" name="society" required>
        </div>
        <div class="mb-3 form-group">
            <label for="commencement">Month & Year of Commencement</label>
            <input type="month" class="form-control" id="commencement" name="commencement" required>
        </div>
        <div class="mb-3 form-group">
            <label for="in_charge">Sister/s in-charge</label>
            <input type="text" class="form-control" id="in_charge" name="in_charge" required>
        </div>
        <div class="mb-3 form-group">
            <label for="beneficiaries">Total Number of Beneficiaries</label>
            <input type="number" class="form-control" id="beneficiaries" name="beneficiaries" required>
        </div>
        <div class="mb-3 form-group">
            <label for="reporting_period">Reporting Period</label>
            <input type="text" class="form-control" id="reporting_period" name="reporting_period" required>
        </div>

        <!-- Dynamic Objectives -->
        <div id="objectives-container"></div>
        <button type="button" class="mb-3 btn btn-primary" id="add-objective">Add Objective</button>

        <!-- Financial Statements -->
        <h3>Statements of Account for the Month</h3>
        <div class="mb-3 form-group">
            <label for="amount_sanctioned">Amount Sanctioned (Rs.)</label>
            <input type="number" class="form-control" id="amount_sanctioned" name="amount_sanctioned" required>
        </div>
        <div class="mb-3 form-group">
            <label for="amount_forwarded">Amount Forwarded from the Last Financial Year (Rs.)</label>
            <input type="number" class="form-control" id="amount_forwarded" name="amount_forwarded" required>
        </div>
        <div class="mb-3 form-group">
            <label for="total_amount">Total Amount (Rs.)</label>
            <input type="number" class="form-control" id="total_amount" name="total_amount" required>
        </div>

        <!-- Photos and Descriptions -->
        <div class="mb-3 form-group">
            <label for="photos">Photos with a Brief Description</label>
            <input type="file" class="form-control" id="photos" name="photos[]" multiple>
        </div>

        <button type="submit" class="btn btn-success">Submit Report</button>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    let objectiveIndex = 0;
    const objectivesContainer = document.getElementById('objectives-container');

    function addObjective() {
        const card = document.createElement('div');
        card.classList.add('card', 'mb-3');
        card.innerHTML = `
            <div class="card-body">
                <h5 class="card-title">Objective ${objectiveIndex + 1}</h5>
                <div class="mb-3 form-group">
                    <label>Expected Outcome</label>
                    <textarea name="objectives[${objectiveIndex}][expected_outcome]" class="form-control" required></textarea>
                </div>
                <div class="mb-3 form-group">
                    <label>Activities and Outcomes</label>
                    <textarea name="objectives[${objectiveIndex}][activities_outcomes]" class="form-control" required></textarea>
                </div>
                <button type="button" class="btn btn-danger remove-objective">Remove Objective</button>
            </div>
        `;
        objectivesContainer.appendChild(card);
        card.querySelector('.remove-objective').addEventListener('click', () => {
            objectivesContainer.removeChild(card);
        });
        objectiveIndex++;
    }

    document.getElementById('add-objective').addEventListener('click', addObjective);
});
</script>
@endsection
