@extends('qreports.app')

@section('content')
<div class="page-content">
    <div class="row justify-content-center">
        <div class="col-md-8 col-xl-8">
            <div class="card">
                <div class="card-body">

                    <h6 class="card-title">Update Information</h6>

                    {{-- <form action="{{ route('reports.store') }}" method="POST"> --}}
                        @csrf
                        <div class="mb-3">
                            <label for="period_start" class="form-label">Period Start</label>
                            <input type="date" name="period_start" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="period_end" class="form-label">Period End</label>
                            <input type="date" name="period_end" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="title" class="form-label">Title of the Project</label>
                            <input type="text" name="title" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="place" class="form-label">Place</label>
                            <input type="text" name="place" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="society" class="form-label">Name of the Society / Trust</label>
                            <input type="text" name="society" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="commencement" class="form-label">Month & Year of Commencement of the Project</label>
                            <input type="month" name="commencement" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="in_charge" class="form-label">Sister/s In-Charge</label>
                            <input type="text" name="in_charge" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="beneficiaries" class="form-label">Total No. of Beneficiaries</label>
                            <input type="number" name="beneficiaries" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="reporting_period" class="form-label">Reporting Period</label>
                            <input type="text" name="reporting_period" class="form-control" required>
                        </div>

                        <h3>Key Information</h3>

                        <div class="mb-3">
                            <label for="goal" class="form-label">Goal of the Project</label>
                            <textarea name="goal" class="form-control" rows="3" required></textarea>
                        </div>

                        @for($i = 1; $i <= 3; $i++)
                        <h3>Objective {{ $i }}</h3>
                        <div class="mb-3">
                            <label for="expected_outcome_{{ $i }}" class="form-label">Expected Outcome</label>
                            <textarea name="expected_outcome_{{ $i }}" class="form-control" rows="2" required></textarea>
                        </div>
                        <h4>Monthly Summary</h4>
                        @for($j = 1; $j <= 4; $j++)
                        <div class="mb-3">
                            <label for="summary_activities_{{ $i }}_{{ $j }}" class="form-label">Summary of Activities (Month {{ $j }})</label>
                            <textarea name="summary_activities_{{ $i }}_{{ $j }}" class="form-control" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="qualitative_quantitative_data_{{ $i }}_{{ $j }}" class="form-label">Qualitative & Quantitative Data (Month {{ $j }})</label>
                            <textarea name="qualitative_quantitative_data_{{ $i }}_{{ $j }}" class="form-control" rows="3" required></textarea>
                        </div>
                        @endfor
                        <div class="mb-3">
                            <label for="not_happened_{{ $i }}" class="form-label">What did not happen?</label>
                            <textarea name="not_happened_{{ $i }}" class="form-control" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="changes_{{ $i }}" class="form-label">Have you made any changes in the project?</label>
                            <textarea name="changes_{{ $i }}" class="form-control" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="lessons_learnt_{{ $i }}" class="form-label">What are the lessons learnt?</label>
                            <textarea name="lessons_learnt_{{ $i }}" class="form-control" rows="3" required></textarea>
                        </div>
                        @endfor

                        <h3>Outlook</h3>
                        <div class="mb-3">
                            <label for="plan_next_month" class="form-label">Plan for Next Month</label>
                            <textarea name="plan_next_month" class="form-control" rows="3" required></textarea>
                        </div>

                        <h3>Statements of Account</h3>
                        <div class="mb-3">
                            <label for="account_period_start" class="form-label">Account Statement Period Start</label>
                            <input type="date" name="account_period_start" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="account_period_end" class="form-label">Account Statement Period End</label>
                            <input type="date" name="account_period_end" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="amount_sanctioned" class="form-label">Amount Sanctioned (Rs.)</label>
                            <input type="number" name="amount_sanctioned" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="amount_forwarded" class="form-label">Amount Forwarded from the Last Financial Year (Rs.)</label>
                            <input type="number" name="amount_forwarded" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="total_amount" class="form-label">Total Amount (Rs.)</label>
                            <input type="number" name="total_amount" class="form-control" required>
                        </div>
                        <!-- Additional expenditure details fields can be added here -->

                        <div class="mb-3">
                            <label for="closing_balance" class="form-label">Total Balance Amount Forwarded for the Following Month (Rs.)</label>
                            <input type="number" name="closing_balance" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label for="photos" class="form-label">Photos with a Brief Description</label>
                            <textarea name="photos" class="form-control" rows="3"></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary me-2">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
