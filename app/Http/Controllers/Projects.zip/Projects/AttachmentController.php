<?php

namespace App\Http\Controllers\Projects;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\OldProjects\Project;
use App\Models\OldProjects\ProjectAttachment;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;

class AttachmentController extends Controller
{
    public function store(Request $request, Project $project)
    {
        Log::info('AttachmentController@store - Data received from form', $request->all());

        $validated = $request->validate([
            'attachments' => 'nullable|array',
            'attachments.*' => 'file|mimes:pdf,doc,docx,xlsx|max:15048',
            'file_name' => 'nullable|array',
            'attachment_descriptions' => 'nullable|array',
        ]);

        try {
            $attachments = [];
            if ($request->hasFile('attachments')) {
                foreach ($request->file('attachments') as $index => $attachment) {
                    $originalFileName = $request->file_name[$index];
                    $originalFileName = str_replace(' ', '_', $originalFileName); // Replace spaces with underscores
                    $extension = $attachment->getClientOriginalExtension();
                    $newFileName = pathinfo($originalFileName, PATHINFO_FILENAME) . '_' . time() . '.' . $extension;
                    $path = $attachment->storeAs('public/attachments', $newFileName); // Ensure correct storage path
                    $publicUrl = Storage::url($path); // Get the public URL

                    $attachments[] = ProjectAttachment::create([
                        'project_id' => $project->project_id,
                        'file_path' => 'attachments/' . $newFileName, // Save relative path
                        'file_name' => $originalFileName,
                        'description' => $request->attachment_descriptions[$index] ?? '',
                        'public_url' => $publicUrl, // Save the public URL
                    ]);
                }
            }

            Log::info('AttachmentController@store - Data passed to database', $attachments);

            return response()->json(['message' => 'Attachments stored successfully', 'attachments' => $attachments], 200);
        } catch (\Exception $e) {
            Log::error('AttachmentController@store - Error', ['error' => $e->getMessage()]);
            return response()->json(['message' => 'There was an error storing the attachments'], 500);
        }
    }

    public function update(Request $request, Project $project)
    {
        Log::info('AttachmentController@update - Data received from form', $request->all());

        $validated = $request->validate([
            'attachments' => 'nullable|array',
            'attachments.*' => 'file|mimes:pdf,doc,docx,xlsx|max:15048',
            'file_name' => 'nullable|array',
            'attachment_descriptions' => 'nullable|array',
        ]);

        try {
            $attachments = [];
            if ($request->hasFile('attachments')) {
                foreach ($request->file('attachments') as $index => $attachment) {
                    $originalFileName = $request->file_name[$index];
                    $originalFileName = str_replace(' ', '_', $originalFileName); // Replace spaces with underscores
                    $extension = $attachment->getClientOriginalExtension();
                    $newFileName = pathinfo($originalFileName, PATHINFO_FILENAME) . '_' . time() . '.' . $extension;
                    $path = $attachment->storeAs('public/attachments', $newFileName); // Ensure correct storage path
                    $publicUrl = Storage::url($path); // Get the public URL

                    $attachments[] = ProjectAttachment::create([
                        'project_id' => $project->project_id,
                        'file_path' => 'attachments/' . $newFileName, // Save relative path
                        'file_name' => $originalFileName,
                        'description' => $request->attachment_descriptions[$index] ?? '',
                        'public_url' => $publicUrl, // Save the public URL
                    ]);
                }
            }

            Log::info('AttachmentController@update - Data passed to database', $attachments);

            return response()->json(['message' => 'Attachments updated successfully', 'attachments' => $attachments], 200);
        } catch (\Exception $e) {
            Log::error('AttachmentController@update - Error', ['error' => $e->getMessage()]);
            return response()->json(['message' => 'There was an error updating the attachments'], 500);
        }
    }




    public function downloadAttachment($id)
    {
        $attachment = ProjectAttachment::findOrFail($id);
        $filePath = storage_path('app/public/' . $attachment->file_path);

        if (!file_exists($filePath)) {
            Log::error('AttachmentController@downloadAttachment - File not found', ['file_path' => $filePath]);
            throw new FileNotFoundException("File does not exist at path: " . $filePath);
        }

        Log::info('AttachmentController@downloadAttachment - File downloaded', ['file_path' => $filePath]);

        return response()->download($filePath, $attachment->file_name);
    }
}
