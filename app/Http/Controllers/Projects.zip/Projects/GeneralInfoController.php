<?php

namespace App\Http\Controllers\Projects;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\OldProjects\Project;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class GeneralInfoController extends Controller
{
    public function store(Request $request)
    {
        Log::info('GeneralInfoController@store - Data received from form', $request->all());

        $validated = $request->validate([
            'project_type' => 'required|string',
            'project_title' => 'required|string|max:255',
            'society_name' => 'required|string|max:255',
            'president_name' => 'required|string|max:255',
            'in_charge' => 'required|exists:users,id',
            'in_charge_name' => 'required|string|max:255',
            'in_charge_mobile' => 'required|string|max:255',
            'in_charge_email' => 'required|string|max:255',
            'executor_name' => 'required|string|max:255',
            'executor_mobile' => 'required|string|max:255',
            'executor_email' => 'required|string|max:255',
            'full_address' => 'required|string|max:255',
            'overall_project_period' => 'required|integer',
            'current_phase' => 'required|integer',
            'commencement_month' => 'nullable|integer|min:1|max:12',
            'commencement_year' => 'nullable|integer|min:1900|max:' . date('Y'),
            'overall_project_budget' => 'required|numeric',
            'coordinator_india_name' => 'nullable|string|max:255',
            'coordinator_india_phone' => 'nullable|string|max:255',
            'coordinator_india_email' => 'nullable|string|max:255',
            'coordinator_luzern_name' => 'nullable|string|max:255',
            'coordinator_luzern_phone' => 'nullable|string|max:255',
            'coordinator_luzern_email' => 'nullable|string|max:255',
        ]);

        try {
            $commencementDate = null;
            if ($request->commencement_year && $request->commencement_month) {
                $commencementDate = sprintf('%04d-%02d-01', $request->commencement_year, $request->commencement_month);
            }

            $project = Project::create([
                'user_id' => Auth::id(),
                'project_type' => $request->project_type,
                'project_title' => $request->project_title,
                'goal' => $request->goal,
                'overall_project_period' => $request->overall_project_period,
                'current_phase' => $request->current_phase,
                'full_address' => $request->full_address,
                'commencement_month_year' => $commencementDate,
                'society_name' => $request->society_name,
                'president_name' => $request->president_name,
                'in_charge' => $request->in_charge,
                'in_charge_name' => $request->in_charge_name,
                'in_charge_mobile' => $request->in_charge_mobile,
                'in_charge_email' => $request->in_charge_email,
                'executor_name' => $request->executor_name,
                'executor_mobile' => $request->executor_mobile,
                'executor_email' => $request->executor_email,
                'coordinator_india_name' => $request->coordinator_india_name,
                'coordinator_india_phone' => $request->coordinator_india_phone,
                'coordinator_india_email' => $request->coordinator_india_email,
                'coordinator_luzern_name' => $request->coordinator_luzern_name,
                'coordinator_luzern_phone' => $request->coordinator_luzern_phone,
                'coordinator_luzern_email' => $request->coordinator_luzern_email,
                'overall_project_budget' => $request->overall_project_budget,
                'amount_forwarded' => $request->amount_forwarded ?? 0,
                'amount_sanctioned' => $request->amount_sanctioned ?? 0,
                'opening_balance' => $request->opening_balance ?? 0,
                'status' => 'underwriting',
            ]);

            Log::info('GeneralInfoController@store - Data passed to database', $project->toArray());

            return $project;
        } catch (\Exception $e) {
            Log::error('GeneralInfoController@store - Error', ['error' => $e->getMessage()]);
            throw $e;
        }
    }

    public function update(Request $request, $id)
    {
        Log::info('GeneralInfoController@update - Data received from form', $request->all());

        $validated = $request->validate([
            'project_type' => 'required|string',
            'project_title' => 'required|string|max:255',
            'society_name' => 'required|string|max:255',
            'president_name' => 'required|string|max:255',
            'in_charge' => 'required|exists:users,id',
            'in_charge_name' => 'required|string|max:255',
            'in_charge_mobile' => 'required|string|max:255',
            'in_charge_email' => 'required|string|max:255',
            'executor_name' => 'required|string|max:255',
            'executor_mobile' => 'required|string|max:255',
            'executor_email' => 'required|string|max:255',
            'full_address' => 'required|string|max:255',
            'overall_project_period' => 'required|integer',
            'current_phase' => 'required|integer',
            'commencement_month' => 'nullable|integer|min:1|max:12',
            'commencement_year' => 'nullable|integer|min:1900|max:' . date('Y'),
            'overall_project_budget' => 'required|numeric',
            'coordinator_india_name' => 'nullable|string|max:255',
            'coordinator_india_phone' => 'nullable|string|max:255',
            'coordinator_india_email' => 'nullable|string|max:255',
            'coordinator_luzern_name' => 'nullable|string|max:255',
            'coordinator_luzern_phone' => 'nullable|string|max:255',
            'coordinator_luzern_email' => 'nullable|string|max:255',
        ]);

        try {
            $project = Project::where('project_id', $id)->firstOrFail();

            $commencementDate = null;
            if ($request->commencement_year && $request->commencement_month) {
                $commencementDate = sprintf('%04d-%02d-01', $request->commencement_year, $request->commencement_month);
            }

            $project->update([
                'project_type' => $request->project_type,
                'project_title' => $request->project_title,
                'goal' => $request->goal,
                'overall_project_period' => $request->overall_project_period,
                'current_phase' => $request->current_phase,
                'full_address' => $request->full_address,
                'commencement_month_year' => $commencementDate,
                'society_name' => $request->society_name,
                'president_name' => $request->president_name,
                'in_charge' => $request->in_charge,
                'in_charge_name' => $request->in_charge_name,
                'in_charge_mobile' => $request->in_charge_mobile,
                'in_charge_email' => $request->in_charge_email,
                'executor_name' => $request->executor_name,
                'executor_mobile' => $request->executor_mobile,
                'executor_email' => $request->executor_email,
                'coordinator_india_name' => $request->coordinator_india_name,
                'coordinator_india_phone' => $request->coordinator_india_phone,
                'coordinator_india_email' => $request->coordinator_india_email,
                'coordinator_luzern_name' => $request->coordinator_luzern_name,
                'coordinator_luzern_phone' => $request->coordinator_luzern_phone,
                'coordinator_luzern_email' => $request->coordinator_luzern_email,
                'overall_project_budget' => $request->overall_project_budget,
                'amount_forwarded' => $request->amount_forwarded ?? 0,
                'amount_sanctioned' => $request->amount_sanctioned,
                'opening_balance' => $request->opening_balance ?? 0,
                'status' => $request->status,
            ]);

            Log::info('GeneralInfoController@update - Data passed to database', $project->toArray());

            return $project;
        } catch (\Exception $e) {
            Log::error('GeneralInfoController@update - Error', ['error' => $e->getMessage()]);
            throw $e;
        }
    }
}
