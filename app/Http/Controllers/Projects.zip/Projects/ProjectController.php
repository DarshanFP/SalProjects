<?php

namespace App\Http\Controllers\Projects;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\OldProjects\Project;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class ProjectController extends Controller
{
    protected $generalInfoController;
    protected $keyInformationController;
    protected $budgetController;
    protected $attachmentController;

    public function __construct(
        GeneralInfoController $generalInfoController,
        KeyInformationController $keyInformationController,
        BudgetController $budgetController,
        AttachmentController $attachmentController
    ) {
        $this->generalInfoController = $generalInfoController;
        $this->keyInformationController = $keyInformationController;
        $this->budgetController = $budgetController;
        $this->attachmentController = $attachmentController;
    }

    public function index()
    {
        $projects = Project::all();
        $user = Auth::user();
        return view('projects.Oldprojects.index', compact('projects', 'user'));
    }

    public function create()
    {
        $users = User::all();
        $user = Auth::user();
        return view('projects.Oldprojects.createProjects', compact('users', 'user'));
    }

    public function store(Request $request)
    {
        Log::info('ProjectController@store - Data received from form', $request->all());

        try {
            // Store general information
            $project = $this->generalInfoController->store($request);

            // Store key information
            $this->keyInformationController->store($request, $project);

            // Store budget information
            $this->budgetController->store($request, $project);

            // Store attachments
            $this->attachmentController->store($request, $project);

            Log::info('ProjectController@store - Project created successfully', ['project_id' => $project->project_id]);

            return redirect()->route('projects.index')->with('success', 'Project created successfully.');
        } catch (\Exception $e) {
            Log::error('ProjectController@store - Error', ['error' => $e->getMessage()]);
            return redirect()->back()->with('error', 'There was an error creating the project. Please try again.');
        }
    }

    public function show($project_id)
    {
        $project = Project::where('project_id', $project_id)->with('budgets', 'attachments')->firstOrFail();
        $user = Auth::user();
        return view('projects.Oldprojects.show', compact('project', 'user'));
    }

    public function edit($id)
    {
        $project = Project::where('project_id', $id)->with('budgets', 'attachments')->firstOrFail();
        $users = User::all();
        $user = Auth::user();
        return view('projects.Oldprojects.edit', compact('project', 'users', 'user'));
    }

    public function update(Request $request, $id)
    {
        Log::info('ProjectController@update - Data received from form', $request->all());

        try {
            // Update general information
            $project = $this->generalInfoController->update($request, $id);

            // Update key information
            $this->keyInformationController->update($request, $project);

            // Update budget information
            $this->budgetController->update($request, $project);

            // Update attachments
            $this->attachmentController->update($request, $project);

            Log::info('ProjectController@update - Project updated successfully', ['project_id' => $project->project_id]);

            return redirect()->route('projects.index')->with('success', 'Project updated successfully.');
        } catch (\Exception $e) {
            Log::error('ProjectController@update - Error', ['error' => $e->getMessage()]);
            return redirect()->back()->with('error', 'There was an error updating the project. Please try again.');
        }
    }
}
